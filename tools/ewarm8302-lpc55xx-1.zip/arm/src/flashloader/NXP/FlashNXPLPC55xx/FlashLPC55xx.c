/*************************************************************************
 *
 *   Used with ICCARM and AARM.
 *
 *    (c) Copyright IAR Systems 2018
 *
 *    File name   : FlashLPC55xx.c
 *    Description : Flash Loader for LPC55xx devices. Uses the device ROM API
 *                  
 *    History :
 *    1. Date        : September 2018
 *       Author      : Stoyan Choynev
 *       Description : initial verstion
 *
 *    $Revision: $
 **************************************************************************/

/** include files **/
#include <stdio.h>
#include "flash_loader.h"       // The flash loader framework API declarations.
#include "flash_loader_extra.h"
#include "fsl_iap1.h"

/** local definitions **/

/** default settings **/

/** external functions **/

/** external data **/

/** internal functions **/

/** public data **/

/** private data **/
static __no_init flash_config_t flashInstance;
/** private functions **/

/** public functions **/
#if USE_ARGC_ARGV
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags,
                   int argc, char const *argv[])
#else
uint32_t FlashInit(void *base_of_flash, uint32_t image_size,
                   uint32_t link_address, uint32_t flags)
#endif
{
uint32_t result = (RESULT_OK);

  // Initialize flash driver
  if(0 != FLASH_Init(&flashInstance))
  {
    result = (RESULT_ERROR);
  }
  else
  {
    /**/
    sprintf(LAYOUT_OVERRIDE_BUFFER,"%d 0x%X\0",\
            flashInstance.PFlashTotalSize/flashInstance.PFlashSectorSize,flashInstance.PFlashSectorSize);
    SET_PAGESIZE_OVERRIDE(flashInstance.PFlashPageSize);

    result |= (OVERRIDE_LAYOUT) | (OVERRIDE_PAGESIZE);
  }
  
  return result;
}

/*************************************************************************
 * Function Name: FlashWrite
 * Parameters: block base address, offset in block, data size, ram buffer
 *             pointer
 * Return:
 *
 * Description
 *
 *************************************************************************/
uint32_t FlashWrite(void *block_start,
                    uint32_t offset_into_block,
                    uint32_t count,
                    char const *buffer)
{
uint32_t result = (RESULT_OK);
uint32_t loadaddr = (uint32_t)block_start+offset_into_block;
uint32_t size = flashInstance.PFlashPageSize;

  while(count)
  {  
    if (0 != FLASH_Program(&flashInstance, loadaddr, (uint8_t *)buffer, size))
    {
      result = (RESULT_ERROR);
      break;
    }
    count -= size;
    loadaddr += size;
    buffer += size;
  }

  return result;
}
/*************************************************************************
 * Function Name: FlashErase
 * Parameters:  Block Address, Block Size
 *
 * Return:
 *
 * Description:
 *
 *************************************************************************/
uint32_t FlashErase(void *block_start,
                    uint32_t block_size)
{
uint32_t result = (RESULT_OK);

  /*check and do not erase the IFR data*/
  if(0x0009D000 > (uint32_t)block_start+block_size)
  {
    if(0 != FLASH_Erase(&flashInstance,(uint32_t)block_start, block_size, kFLASH_ApiEraseKey))
    {
      result = (RESULT_ERROR);
    }
  }
  
  return result;
}
